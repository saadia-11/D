@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-5">
    <div>
        <h1 class="fw-bold text-dark m-0">Gestion de la Facturation</h1>
        <p class="text-muted m-0">Prestations de transit, calcul de la TVA et suivi des débours clients</p>
    </div>
    <button class="btn text-white px-4 py-2 rounded-3 border-0 shadow-sm" style="background-color: #6b21a8;" data-bs-toggle="modal" data-bs-target="#addFactureModal">
        <i class="fas fa-file-invoice-dollar me-2"></i> Émettre une Facture
    </button>
</div>

<div class="card shadow-sm border-0 rounded-3 p-4 bg-white">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light text-muted small text-uppercase">
                <tr>
                    <th>N° Facture</th>
                    <th>Client / Dossier DUM</th>
                    <th>Prestation HT</th>
                    <th>Débours Exonérés</th>
                    <th>Total TTC</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse($factures as $facture)
                <tr>
                    <td class="fw-bold text-dark" style="color: #6b21a8;">#FAC-{{ str_pad($facture->id, 5, '0', STR_PAD_LEFT) }}</td>
                    <td>
                        <div class="fw-semibold">{{ $facture->client->nom ?? 'Client Professionnel' }}</div>
                        <small class="text-muted">DUM: {{ $facture->dossier->num_dum ?? 'N/A' }}</small>
                    </td>
                    <td>{{ number_format($facture->montant_ht, 2, ',', ' ') }} DH</td>
                    <td class="text-secondary">{{ number_format($facture->debours, 2, ',', ' ') }} DH</td>
                    <td class="fw-bold" style="color: #6b21a8;">{{ number_format(($facture->montant_ht * 1.2) + $facture->debours, 2, ',', ' ') }} DH</td>
                    <td class="text-center">
                        <button class="btn btn-sm text-white px-3" style="background-color: #6b21a8;"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center text-muted py-5">Aucune facture émise dans le système.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
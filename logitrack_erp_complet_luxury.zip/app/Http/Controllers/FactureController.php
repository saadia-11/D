<?php
namespace App\Http\Controllers;
use App\Models\{Facture, DossierTransit};
use Illuminate\Http\Request;
class FactureController extends Controller {
    public function index() { $factures = Facture::with("dossier.client")->latest()->get(); $dossiers = DossierTransit::doesntHave("facture")->where("statut", "!=", "Créé")->get(); return view("factures.index", compact("factures", "dossiers")); }
    public function store(Request $request) {
        $total = ($request->montant_prestations * 1.20) + $request->montant_debours;
        Facture::create(["dossier_id" => $request->dossier_id, "numero_facture" => "TR-2026-".rand(100,999), "date_facture" => now(), "montant_prestations" => $request->montant_prestations, "montant_debours" => $request->montant_debours, "total_ttc" => $total]);
        return redirect()->route("factures.index")->with("success", "Facture générée.");
    }
}
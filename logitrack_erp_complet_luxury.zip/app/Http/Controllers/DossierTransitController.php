<?php
namespace App\Http\Controllers;
use App\Models\{DossierTransit, Client, Chauffeur};
use Illuminate\Http\Request;
class DossierTransitController extends Controller {
    public function index() {
        $dossiers = DossierTransit::with(["client", "chauffeur"])->latest()->get();
        $clients = Client::all(); $chauffeurs = Chauffeur::where("statut_dispo", "Disponible")->get();
        return view("dossiers.index", compact("dossiers", "clients", "chauffeurs"));
    }
    public function store(Request $request) { DossierTransit::create($request->all()); return redirect()->route("dossiers.index")->with("success", "Dossier ouvert."); }
}
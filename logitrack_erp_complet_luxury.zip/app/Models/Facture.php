<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Facture extends Model {
    protected $fillable = ["dossier_id", "numero_facture", "date_facture", "montant_prestations", "montant_debours", "total_ttc", "statut_paiement"];
    public function dossier() { return $this->belongsTo(DossierTransit::class); }
}
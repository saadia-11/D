<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Maintenance extends Model {
    protected $fillable = ["chauffeur_id", "type_panne", "date_reparation", "montant_facture", "statut"];
    public function chauffeur() { return $this->belongsTo(Chauffeur::class); }
}
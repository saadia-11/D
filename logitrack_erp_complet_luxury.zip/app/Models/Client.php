<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Client extends Model {
    protected $fillable = ["nom", "prenom", "email", "telephone", "adresse", "entreprise", "ice"];
    public function dossiers() { return $this->hasMany(DossierTransit::class); }
}
<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class DossierTransit extends Model {
    protected $table = "dossiers_transit";
    protected $fillable = ["client_id", "chauffeur_id", "numero_dum", "mode_transport", "provenance_destination", "description_marchandise", "valeur_declarée", "statut"];
    public function client() { return $this->belongsTo(Client::class); }
    public function chauffeur() { return $this->belongsTo(Chauffeur::class); }
    public function facture() { return $this->hasOne(Facture::class, "dossier_id"); }
    public function fraisRoute() { return $this->hasMany(FraisRoute::class, "dossier_id"); }
}